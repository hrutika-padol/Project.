package ecommerce.DTO;

public class CartDTO {

	private int prodid;
	private String pcat;
	private String pname;
	private int price;
	private int qty;
	public int getProdid() {
		return prodid;
	}
	public void setProdid(int prodid) {
		this.prodid = prodid;
	}
	public String getPcat() {
		return pcat;
	}
	public void setPcat(String pcat) {
		this.pcat = pcat;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "CartDTO [prodid=" + prodid + ", pcat=" + pcat + ", pname=" + pname + ", price=" + price + ", qty=" + qty
				+ "]";
	}
	
	
}
